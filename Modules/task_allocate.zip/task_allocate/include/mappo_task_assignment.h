#ifndef MAPPO_TASK_ASSIGNMENT_H
#define MAPPO_TASK_ASSIGNMENT_H

#include <Eigen/Eigen>
#include <algorithm>
#include <cmath>
#include <limits>
#include <numeric>
#include <sstream>
#include <string>
#include <vector>

namespace mappo_task_assignment
{

enum TaskType
{
    ATTACK = 0,
    RECON  = 1,
    JAM    = 2
};

inline std::string taskTypeToString(int type)
{
    switch(type)
    {
        case ATTACK: return "Attack";
        case RECON:  return "Recon";
        case JAM:    return "Jam";
        default:     return "Unknown";
    }
}

inline std::string taskTypeToChinese(int type)
{
    switch(type)
    {
        case ATTACK: return "攻击";
        case RECON:  return "侦察";
        case JAM:    return "干扰";
        default:     return "未知";
    }
}

struct TaskInfo
{
    int id = 0;
    int type = RECON;
    Eigen::Vector3d position = Eigen::Vector3d::Zero();
    double priority = 1.0;
    bool assigned = false;
};

struct UavInfo
{
    int id = 0;
    Eigen::Vector3d position = Eigen::Vector3d::Zero();
    Eigen::Vector3d velocity = Eigen::Vector3d::Zero();
    double energy = 100.0;
    bool available = true;
    bool has_state = false;
    std::vector<int> capability = std::vector<int>(3, 1);
};

struct AgentDecision
{
    int uav_id = 0;
    int task_id = -1;          // -1 means idle
    int task_index = -1;
    double score = -1e9;
    double idle_score = -1e9;
    std::vector<double> task_scores;
};

struct AssignmentResult
{
    int uav_id = 0;
    int task_id = -1;
    int task_index = -1;
    int task_type = -1;
    Eigen::Vector3d uav_position = Eigen::Vector3d::Zero();
    Eigen::Vector3d task_position = Eigen::Vector3d::Zero();
    double score = 0.0;
    double distance = 0.0;
};

struct AssignmentMetrics
{
    int total_uav = 0;
    int total_task = 0;
    int assigned_num = 0;
    int unassigned_task_num = 0;
    int idle_uav_num = 0;
    double total_distance = 0.0;
    double avg_distance = 0.0;
    double success_rate = 0.0;
    double compute_time_ms = 0.0;
};

class LinearMappoActor
{
public:
    // Minimal actor used for MAPPO deployment verification.
    // The vector corresponds to:
    // [bias, near_score, priority_norm, energy_norm, capability, availability, task_unassigned]
    LinearMappoActor()
    {
        weights_ = { -1.0, 3.0, 2.0, 0.5, 5.0, 2.0, 1.0 };
        idle_weights_ = { 0.0, -0.2, -0.1 };
        max_distance_ = 60.0;
    }

    void setWeights(const std::vector<double>& weights)
    {
        if(weights.size() == 7)
        {
            weights_ = weights;
        }
    }

    void setIdleWeights(const std::vector<double>& weights)
    {
        if(weights.size() == 3)
        {
            idle_weights_ = weights;
        }
    }

    void setMaxDistance(double max_distance)
    {
        max_distance_ = std::max(1.0, max_distance);
    }

    double calcTaskLogit(const UavInfo& uav, const TaskInfo& task) const
    {
        const double distance = (uav.position - task.position).norm();
        const double near_score = 1.0 - std::min(distance / max_distance_, 1.0);
        const double priority_norm = std::max(0.0, std::min(task.priority / 10.0, 1.0));
        const double energy_norm = std::max(0.0, std::min(uav.energy / 100.0, 1.0));
        const double capability = hasCapability(uav, task.type) ? 1.0 : 0.0;
        const double availability = uav.available ? 1.0 : 0.0;
        const double unassigned = task.assigned ? 0.0 : 1.0;

        std::vector<double> obs = {1.0, near_score, priority_norm, energy_norm,
                                   capability, availability, unassigned};
        double logit = 0.0;
        for(size_t i = 0; i < weights_.size(); ++i)
        {
            logit += weights_[i] * obs[i];
        }

        if(!uav.available)
        {
            logit -= 100.0;
        }
        if(!hasCapability(uav, task.type))
        {
            logit -= 100.0;
        }
        if(task.assigned)
        {
            logit -= 100.0;
        }
        return logit;
    }

    double calcIdleLogit(const UavInfo& uav, const std::vector<TaskInfo>& tasks) const
    {
        int feasible_task_num = 0;
        for(const auto& task : tasks)
        {
            if(!task.assigned && hasCapability(uav, task.type))
            {
                feasible_task_num++;
            }
        }
        const double energy_norm = std::max(0.0, std::min(uav.energy / 100.0, 1.0));
        const double no_feasible = feasible_task_num == 0 ? 1.0 : 0.0;
        return idle_weights_[0] + idle_weights_[1] * energy_norm + idle_weights_[2] * no_feasible;
    }

    static bool hasCapability(const UavInfo& uav, int task_type)
    {
        if(task_type < 0 || task_type >= static_cast<int>(uav.capability.size()))
        {
            return false;
        }
        return uav.capability[task_type] != 0;
    }

private:
    std::vector<double> weights_;
    std::vector<double> idle_weights_;
    double max_distance_;
};

class MappoAssignmentSolver
{
public:
    void setActor(const LinearMappoActor& actor)
    {
        actor_ = actor;
    }

    // This is a MAPPO sequential decision solver with action masks.
    // It does NOT use Hungarian matching as the final assignment method.
    // The actor supplies task logits, and the mask removes invalid actions:
    // 1) UAV capability mismatch;
    // 2) task already selected by previous UAV;
    // 3) actions that would make the remaining one-to-one assignment infeasible.
    std::vector<AgentDecision> inferAgentDecisions(const std::vector<UavInfo>& uavs,
                                                    const std::vector<TaskInfo>& tasks) const
    {
        std::vector<AgentDecision> decisions;
        std::vector<int> task_used(tasks.size(), 0);

        for(size_t i = 0; i < uavs.size(); ++i)
        {
            AgentDecision decision;
            decision.uav_id = uavs[i].id;
            decision.idle_score = actor_.calcIdleLogit(uavs[i], tasks);
            decision.task_scores.resize(tasks.size(), -1e9);

            double best_score = -1e9;
            int best_task_index = -1;
            for(size_t j = 0; j < tasks.size(); ++j)
            {
                if(task_used[j])
                {
                    continue;
                }
                if(!uavs[i].available || !LinearMappoActor::hasCapability(uavs[i], tasks[j].type))
                {
                    continue;
                }

                const double score = actor_.calcTaskLogit(uavs[i], tasks[j]);
                decision.task_scores[j] = score;

                if(!passesLookAheadMask(uavs, tasks, i, static_cast<int>(j), task_used))
                {
                    continue;
                }

                if(score > best_score)
                {
                    best_score = score;
                    best_task_index = static_cast<int>(j);
                }
            }

            if(best_task_index >= 0)
            {
                decision.task_index = best_task_index;
                decision.task_id = tasks[best_task_index].id;
                decision.score = best_score;
                task_used[best_task_index] = 1;
            }
            else
            {
                decision.task_index = -1;
                decision.task_id = -1;
                decision.score = decision.idle_score;
            }
            decisions.push_back(decision);
        }
        return decisions;
    }

    std::vector<AssignmentResult> solve(const std::vector<UavInfo>& uavs,
                                        const std::vector<TaskInfo>& tasks,
                                        AssignmentMetrics& metrics,
                                        std::vector<int>& unassigned_tasks,
                                        std::vector<int>& idle_uavs) const
    {
        std::vector<int> task_used(tasks.size(), 0);
        std::vector<int> uav_used(uavs.size(), 0);
        std::vector<AssignmentResult> results;

        // MAPPO sequential decision: UAV1 -> UAV2 -> ... -> UAVN.
        // Each step chooses one action from the masked task set.
        for(size_t i = 0; i < uavs.size(); ++i)
        {
            const auto& uav = uavs[i];
            if(!uav.available)
            {
                continue;
            }

            double best_score = -1e9;
            int best_task_index = -1;

            for(size_t j = 0; j < tasks.size(); ++j)
            {
                if(task_used[j])
                {
                    continue;
                }
                if(!LinearMappoActor::hasCapability(uav, tasks[j].type))
                {
                    continue;
                }
                if(!passesLookAheadMask(uavs, tasks, i, static_cast<int>(j), task_used))
                {
                    continue;
                }

                const double score = actor_.calcTaskLogit(uav, tasks[j]);
                if(score > best_score)
                {
                    best_score = score;
                    best_task_index = static_cast<int>(j);
                }
            }

            // Idle is only allowed when the action mask has no feasible task.
            // This keeps the one-to-one assignment as complete as possible when a feasible assignment exists.
            if(best_task_index < 0)
            {
                continue;
            }

            const auto& task = tasks[best_task_index];
            AssignmentResult r;
            r.uav_id = uav.id;
            r.task_id = task.id;
            r.task_index = best_task_index;
            r.task_type = task.type;
            r.uav_position = uav.position;
            r.task_position = task.position;
            r.score = best_score;
            r.distance = (uav.position - task.position).norm();
            results.push_back(r);

            uav_used[i] = 1;
            task_used[best_task_index] = 1;
        }

        unassigned_tasks.clear();
        idle_uavs.clear();
        for(size_t j = 0; j < tasks.size(); ++j)
        {
            if(!task_used[j])
            {
                unassigned_tasks.push_back(tasks[j].id);
            }
        }
        for(size_t i = 0; i < uavs.size(); ++i)
        {
            if(!uav_used[i])
            {
                idle_uavs.push_back(uavs[i].id);
            }
        }

        metrics.total_uav = static_cast<int>(uavs.size());
        metrics.total_task = static_cast<int>(tasks.size());
        metrics.assigned_num = static_cast<int>(results.size());
        metrics.unassigned_task_num = static_cast<int>(unassigned_tasks.size());
        metrics.idle_uav_num = static_cast<int>(idle_uavs.size());
        metrics.total_distance = 0.0;
        for(const auto& r : results)
        {
            metrics.total_distance += r.distance;
        }
        metrics.avg_distance = results.empty() ? 0.0 : metrics.total_distance / results.size();
        metrics.success_rate = tasks.empty() ? 0.0 : static_cast<double>(results.size()) / tasks.size();
        return results;
    }

private:
    bool passesLookAheadMask(const std::vector<UavInfo>& uavs,
                             const std::vector<TaskInfo>& tasks,
                             size_t current_uav_index,
                             int selected_task_index,
                             const std::vector<int>& task_used) const
    {
        if(selected_task_index < 0 || selected_task_index >= static_cast<int>(tasks.size()))
        {
            return false;
        }

        std::vector<int> next_task_used = task_used;
        next_task_used[selected_task_index] = 1;

        std::vector<int> remaining_tasks;
        for(size_t j = 0; j < tasks.size(); ++j)
        {
            if(!next_task_used[j])
            {
                remaining_tasks.push_back(static_cast<int>(j));
            }
        }

        std::vector<int> remaining_uavs;
        for(size_t i = current_uav_index + 1; i < uavs.size(); ++i)
        {
            if(uavs[i].available)
            {
                remaining_uavs.push_back(static_cast<int>(i));
            }
        }

        // If there are fewer remaining tasks than UAVs, it is fine for some UAVs to become idle.
        // If there are more remaining tasks than UAVs, not all tasks can be assigned anyway;
        // still require each remaining UAV to have at least one executable task when possible.
        if(remaining_tasks.empty())
        {
            return true;
        }
        if(remaining_uavs.empty())
        {
            return false;
        }

        const int assign_need = std::min(static_cast<int>(remaining_tasks.size()),
                                         static_cast<int>(remaining_uavs.size()));
        return maxFeasibleFutureAssignments(uavs, tasks, remaining_uavs, remaining_tasks) >= assign_need;
    }

    int maxFeasibleFutureAssignments(const std::vector<UavInfo>& uavs,
                                     const std::vector<TaskInfo>& tasks,
                                     const std::vector<int>& remaining_uavs,
                                     const std::vector<int>& remaining_tasks) const
    {
        std::vector<int> task_taken(remaining_tasks.size(), 0);
        int best = 0;
        dfsFutureAssign(uavs, tasks, remaining_uavs, remaining_tasks, 0, task_taken, 0, best);
        return best;
    }

    void dfsFutureAssign(const std::vector<UavInfo>& uavs,
                         const std::vector<TaskInfo>& tasks,
                         const std::vector<int>& remaining_uavs,
                         const std::vector<int>& remaining_tasks,
                         size_t uav_pos,
                         std::vector<int>& task_taken,
                         int assigned_count,
                         int& best) const
    {
        if(assigned_count > best)
        {
            best = assigned_count;
        }
        if(uav_pos >= remaining_uavs.size())
        {
            return;
        }
        if(assigned_count + static_cast<int>(remaining_uavs.size() - uav_pos) <= best)
        {
            return;
        }

        const int uav_index = remaining_uavs[uav_pos];

        // Idle branch: allowed in future steps when no valid task is selected by that UAV.
        dfsFutureAssign(uavs, tasks, remaining_uavs, remaining_tasks,
                        uav_pos + 1, task_taken, assigned_count, best);

        for(size_t k = 0; k < remaining_tasks.size(); ++k)
        {
            if(task_taken[k])
            {
                continue;
            }
            const int task_index = remaining_tasks[k];
            if(!LinearMappoActor::hasCapability(uavs[uav_index], tasks[task_index].type))
            {
                continue;
            }
            task_taken[k] = 1;
            dfsFutureAssign(uavs, tasks, remaining_uavs, remaining_tasks,
                            uav_pos + 1, task_taken, assigned_count + 1, best);
            task_taken[k] = 0;
        }
    }

    LinearMappoActor actor_;
};

inline std::string vectorToString(const std::vector<int>& v)
{
    if(v.empty())
    {
        return "none";
    }
    std::stringstream ss;
    for(size_t i = 0; i < v.size(); ++i)
    {
        ss << v[i];
        if(i + 1 < v.size()) ss << ",";
    }
    return ss.str();
}

} // namespace mappo_task_assignment

#endif // MAPPO_TASK_ASSIGNMENT_H
