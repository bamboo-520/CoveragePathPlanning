#include <ros/ros.h>
#include <Eigen/Eigen>
#include <XmlRpcValue.h>
#include <boost/bind.hpp>

#include <gazebo_msgs/DeleteModel.h>
#include <gazebo_msgs/SpawnModel.h>
#include <gazebo_msgs/ModelStates.h>
#include <geometry_msgs/Point.h>
#include <geometry_msgs/Pose.h>
#include <geometry_msgs/PoseStamped.h>
#include <nav_msgs/Path.h>
#include <prometheus_msgs/DroneState.h>
#include <prometheus_msgs/SwarmCommand.h>
#include <std_msgs/String.h>
#include <visualization_msgs/MarkerArray.h>

#include <algorithm>
#include <iomanip>
#include <iostream>
#include <map>
#include <sstream>
#include <string>
#include <vector>

#include "mappo_task_assignment.h"

using namespace std;
using namespace mappo_task_assignment;


struct StaticObstacle
{
    int id = 0;
    // 0 = box/building, 1 = cylinder/tower, 2 = danger zone cylinder.
    int type = 0;
    Eigen::Vector3d position = Eigen::Vector3d::Zero();
    // Box: [length_x, width_y, height_z]. Cylinder: [radius, unused, height_z].
    Eigen::Vector3d size = Eigen::Vector3d::Ones();
    double r = 0.5;
    double g = 0.5;
    double b = 0.5;
    double a = 0.8;
};

#define NODE_NAME "swarm_task_assignment_mappo"
#define MAX_UAV_NUM 50

class SwarmTaskAssignmentMappoNode
{
public:
    SwarmTaskAssignmentMappoNode() : nh_("~")
    {
        nh_.param<int>("swarm_num_uav", swarm_num_uav_, 5);
        nh_.param<bool>("use_demo_positions", use_demo_positions_, true);
        nh_.param<bool>("auto_dispatch_commands", auto_dispatch_commands_, false);
        nh_.param<bool>("run_once", run_once_, false);
        nh_.param<double>("assignment_period", assignment_period_, 2.0);
        nh_.param<string>("frame_id", frame_id_, string("world"));
        nh_.param<double>("default_energy", default_energy_, 100.0);
        nh_.param<double>("default_height", default_height_, 2.0);
        nh_.param<double>("yaw_ref", yaw_ref_, 0.0);
        nh_.param<double>("max_distance", max_distance_, 60.0);

        // RViz/Gazebo visualization parameters.
        nh_.param<bool>("enable_rviz_visualization", enable_rviz_visualization_, true);
        nh_.param<bool>("publish_demo_paths", publish_demo_paths_, true);
        nh_.param<bool>("enable_gazebo_visualization", enable_gazebo_visualization_, true);
        nh_.param<bool>("gazebo_respawn_each_assignment", gazebo_respawn_each_assignment_, false);
        nh_.param<int>("path_sample_num", path_sample_num_, 16);
        nh_.param<double>("path_mid_height", path_mid_height_, 1.2);
        nh_.param<double>("path_side_offset", path_side_offset_, 1.0);
        nh_.param<double>("gazebo_task_radius", gazebo_task_radius_, 0.35);
        nh_.param<double>("gazebo_uav_marker_radius", gazebo_uav_marker_radius_, 0.25);
        nh_.param<double>("gazebo_path_marker_radius", gazebo_path_marker_radius_, 0.12);
        nh_.param<bool>("gazebo_show_uav_start_spheres", gazebo_show_uav_start_spheres_, false);
        // Gazebo spheres are only visualization markers. They must not participate in physics,
        // otherwise a marker spawned at/near a UAV can push the real UAV model away.
        nh_.param<bool>("gazebo_visual_collision", gazebo_visual_collision_, false);
        nh_.param<int>("gazebo_path_skip_start_points", gazebo_path_skip_start_points_, 2);
        nh_.param<int>("gazebo_path_skip_goal_points", gazebo_path_skip_goal_points_, 1);
        nh_.param<double>("gazebo_path_marker_z_offset", gazebo_path_marker_z_offset_, 0.15);

        // Stage 2: static obstacle visualization. These obstacles are visual/environment objects
        // for task allocation scene construction only. Demo paths are not real obstacle-avoidance paths yet.
        nh_.param<bool>("enable_obstacle_visualization", enable_obstacle_visualization_, true);
        nh_.param<bool>("gazebo_obstacle_collision", gazebo_obstacle_collision_, true);

        // RViz can not display Gazebo SDF models automatically.  Therefore UAV bodies are
        // published as RViz mesh markers, and their poses can be read from /gazebo/model_states.
        nh_.param<bool>("visualize_uav_as_mesh", visualize_uav_as_mesh_, true);
        nh_.param<bool>("use_gazebo_model_states_for_rviz_uav", use_gazebo_model_states_for_rviz_uav_, true);
        nh_.param<bool>("use_gazebo_model_states_for_assignment", use_gazebo_model_states_for_assignment_, true);
        nh_.param<bool>("wait_for_gazebo_model_states", wait_for_gazebo_model_states_, true);
        nh_.param<string>("default_uav_mesh_resource", default_uav_mesh_resource_, string(""));
        nh_.param<double>("rviz_uav_mesh_scale", rviz_uav_mesh_scale_, 1.0);
        nh_.param<double>("rviz_uav_mesh_z_offset", rviz_uav_mesh_z_offset_, 0.0);
        nh_.param<double>("uav_model_marker_period", uav_model_marker_period_, 0.10);

        loadUavModelNames();
        loadUavMeshResources();

        loadActorParams();
        loadUavCapabilityMatrix();
        loadTaskList();
        loadObstacleList();
        loadDemoUavPositions();
        initRosIO();

        solver_.setActor(actor_);

        ROS_INFO("[%s] MAPPO task assignment node started.", NODE_NAME);
        ROS_INFO("[%s] swarm_num_uav=%d, task_num=%zu, use_demo_positions=%s, rviz=%s, gazebo=%s, auto_dispatch_commands=%s",
                 NODE_NAME, swarm_num_uav_, tasks_.size(), use_demo_positions_ ? "true" : "false",
                 enable_rviz_visualization_ ? "true" : "false", enable_gazebo_visualization_ ? "true" : "false",
                 auto_dispatch_commands_ ? "true" : "false");
        ROS_INFO("[%s] stage2_obstacle_visualization=%s, obstacle_num=%zu, gazebo_obstacle_collision=%s",
                 NODE_NAME, enable_obstacle_visualization_ ? "true" : "false", obstacles_.size(),
                 gazebo_obstacle_collision_ ? "true" : "false");
        ROS_INFO("[%s] RViz UAV model display: mesh=%s, gazebo_model_states=%s, default_mesh='%s'",
                 NODE_NAME, visualize_uav_as_mesh_ ? "true" : "false",
                 use_gazebo_model_states_for_rviz_uav_ ? "true" : "false",
                 default_uav_mesh_resource_.c_str());
        ROS_INFO("[%s] Assignment position source: %s", NODE_NAME,
                 use_gazebo_model_states_for_assignment_ ? "Gazebo /gazebo/model_states world pose" : "DroneState /uavX/prometheus/drone_state");

        assignment_timer_ = nh_.createTimer(ros::Duration(assignment_period_),
                                            &SwarmTaskAssignmentMappoNode::assignmentTimerCb,
                                            this);
    }

private:
    ros::NodeHandle nh_;
    int swarm_num_uav_ = 5;
    bool use_demo_positions_ = true;
    bool auto_dispatch_commands_ = false;
    bool run_once_ = false;
    bool has_run_once_ = false;
    double assignment_period_ = 2.0;
    string frame_id_ = "world";
    double default_energy_ = 100.0;
    double default_height_ = 2.0;
    double yaw_ref_ = 0.0;
    double max_distance_ = 60.0;

    bool enable_rviz_visualization_ = true;
    bool publish_demo_paths_ = true;
    bool enable_gazebo_visualization_ = true;
    bool gazebo_respawn_each_assignment_ = false;
    bool gazebo_models_spawned_ = false;
    int path_sample_num_ = 16;
    double path_mid_height_ = 1.2;
    double path_side_offset_ = 1.0;
    double gazebo_task_radius_ = 0.35;
    double gazebo_uav_marker_radius_ = 0.25;
    double gazebo_path_marker_radius_ = 0.12;
    bool gazebo_show_uav_start_spheres_ = false;
    bool gazebo_visual_collision_ = false;
    int gazebo_path_skip_start_points_ = 2;
    int gazebo_path_skip_goal_points_ = 1;
    double gazebo_path_marker_z_offset_ = 0.15;
    bool enable_obstacle_visualization_ = true;
    bool gazebo_obstacle_collision_ = true;
    vector<StaticObstacle> obstacles_;

    bool visualize_uav_as_mesh_ = true;
    bool use_gazebo_model_states_for_rviz_uav_ = true;
    bool use_gazebo_model_states_for_assignment_ = true;
    bool wait_for_gazebo_model_states_ = true;
    string default_uav_mesh_resource_;
    double rviz_uav_mesh_scale_ = 1.0;
    double rviz_uav_mesh_z_offset_ = 0.0;
    double uav_model_marker_period_ = 0.10;
    vector<string> uav_model_names_;
    vector<string> uav_mesh_resources_;
    std::map<string, geometry_msgs::Pose> gazebo_model_pose_map_;

    vector<UavInfo> uavs_;
    vector<TaskInfo> tasks_;
    LinearMappoActor actor_;
    MappoAssignmentSolver solver_;

    ros::Subscriber drone_state_sub_[MAX_UAV_NUM + 1];
    ros::Subscriber gazebo_model_state_sub_;
    ros::Publisher command_pub_[MAX_UAV_NUM + 1];
    ros::Publisher path_pub_[MAX_UAV_NUM + 1];
    ros::Publisher marker_pub_;
    ros::Publisher uav_model_marker_pub_;
    ros::Publisher result_text_pub_;
    ros::ServiceClient gazebo_spawn_client_;
    ros::ServiceClient gazebo_delete_client_;
    ros::Timer assignment_timer_;
    ros::Timer uav_model_marker_timer_;
    int command_id_[MAX_UAV_NUM + 1] = {0};
    vector<string> gazebo_model_names_;

private:
    bool parseStringArray(const XmlRpc::XmlRpcValue& row, vector<string>& values) const
    {
        if(row.getType() != XmlRpc::XmlRpcValue::TypeArray)
        {
            return false;
        }
        values.clear();
        for(int i = 0; i < row.size(); ++i)
        {
            if(row[i].getType() == XmlRpc::XmlRpcValue::TypeString)
            {
                values.push_back(static_cast<string>(row[i]));
            }
            else
            {
                std::stringstream ss;
                ss << row[i];
                values.push_back(ss.str());
            }
        }
        return true;
    }


    string stringVectorToString(const vector<string>& v) const
    {
        std::stringstream ss;
        ss << "[";
        for(size_t i = 0; i < v.size(); ++i)
        {
            ss << v[i];
            if(i + 1 < v.size()) ss << ",";
        }
        ss << "]";
        return ss.str();
    }

    void loadUavModelNames()
    {
        uav_model_names_.clear();
        uav_model_names_.resize(swarm_num_uav_);
        for(int i = 0; i < swarm_num_uav_; ++i)
        {
            uav_model_names_[i] = "uav" + std::to_string(i + 1);
        }

        XmlRpc::XmlRpcValue names;
        if(nh_.getParam("uav_model_names", names) && names.getType() == XmlRpc::XmlRpcValue::TypeArray)
        {
            vector<string> parsed;
            if(parseStringArray(names, parsed))
            {
                for(size_t i = 0; i < parsed.size() && i < uav_model_names_.size(); ++i)
                {
                    if(!parsed[i].empty())
                    {
                        uav_model_names_[i] = parsed[i];
                    }
                }
            }
        }
    }

    void loadUavMeshResources()
    {
        uav_mesh_resources_.clear();
        uav_mesh_resources_.resize(swarm_num_uav_, default_uav_mesh_resource_);

        XmlRpc::XmlRpcValue meshes;
        if(nh_.getParam("uav_mesh_resources", meshes) && meshes.getType() == XmlRpc::XmlRpcValue::TypeArray)
        {
            vector<string> parsed;
            if(parseStringArray(meshes, parsed))
            {
                for(size_t i = 0; i < parsed.size() && i < uav_mesh_resources_.size(); ++i)
                {
                    if(!parsed[i].empty())
                    {
                        uav_mesh_resources_[i] = parsed[i];
                    }
                }
            }
        }
    }

    void loadActorParams()
    {
        vector<double> actor_weights;
        if(nh_.getParam("actor_weights", actor_weights))
        {
            actor_.setWeights(actor_weights);
        }
        vector<double> idle_weights;
        if(nh_.getParam("idle_weights", idle_weights))
        {
            actor_.setIdleWeights(idle_weights);
        }
        actor_.setMaxDistance(max_distance_);
    }

    bool parseIntArray(const XmlRpc::XmlRpcValue& row, vector<int>& values) const
    {
        if(row.getType() != XmlRpc::XmlRpcValue::TypeArray)
        {
            return false;
        }
        values.clear();
        for(int i = 0; i < row.size(); ++i)
        {
            values.push_back(static_cast<int>(row[i]));
        }
        return true;
    }

    bool parseDoubleArray(const XmlRpc::XmlRpcValue& row, vector<double>& values) const
    {
        if(row.getType() != XmlRpc::XmlRpcValue::TypeArray)
        {
            return false;
        }
        values.clear();
        for(int i = 0; i < row.size(); ++i)
        {
            if(row[i].getType() == XmlRpc::XmlRpcValue::TypeInt)
            {
                values.push_back(static_cast<int>(row[i]));
            }
            else
            {
                values.push_back(static_cast<double>(row[i]));
            }
        }
        return true;
    }

    void loadUavCapabilityMatrix()
    {
        uavs_.clear();
        uavs_.resize(swarm_num_uav_);
        for(int i = 0; i < swarm_num_uav_; ++i)
        {
            uavs_[i].id = i + 1;
            uavs_[i].energy = default_energy_;
            uavs_[i].available = true;
            uavs_[i].capability = vector<int>(3, 1);
        }

        XmlRpc::XmlRpcValue matrix;
        if(!nh_.getParam("uav_capability_matrix", matrix) || matrix.getType() != XmlRpc::XmlRpcValue::TypeArray)
        {
            ROS_WARN("[%s] No valid uav_capability_matrix, use all-capable default matrix.", NODE_NAME);
            return;
        }

        for(int i = 0; i < std::min(swarm_num_uav_, static_cast<int>(matrix.size())); ++i)
        {
            vector<int> row;
            if(parseIntArray(matrix[i], row) && row.size() >= 3)
            {
                uavs_[i].capability[ATTACK] = row[0];
                uavs_[i].capability[RECON]  = row[1];
                uavs_[i].capability[JAM]    = row[2];
            }
        }
    }

    void loadTaskList()
    {
        tasks_.clear();
        XmlRpc::XmlRpcValue task_list;
        if(!nh_.getParam("task_list", task_list) || task_list.getType() != XmlRpc::XmlRpcValue::TypeArray)
        {
            ROS_WARN("[%s] No valid task_list. Use default 5-task demo.", NODE_NAME);
            addTask(1, ATTACK, 10.0,  6.0, default_height_, 9.0);
            addTask(2, RECON,  10.0, -6.0, default_height_, 7.0);
            addTask(3, JAM,    12.0, -3.0, default_height_, 8.0);
            addTask(4, RECON,   8.0,  3.0, default_height_, 5.0);
            addTask(5, ATTACK, 12.0,  0.0, default_height_, 6.0);
            return;
        }

        for(int i = 0; i < task_list.size(); ++i)
        {
            vector<double> row;
            if(!parseDoubleArray(task_list[i], row) || row.size() < 6)
            {
                ROS_WARN("[%s] Skip invalid task row %d. Expected [id,type,x,y,z,priority].", NODE_NAME, i);
                continue;
            }
            addTask(static_cast<int>(row[0]), static_cast<int>(row[1]),
                    row[2], row[3], row[4], row[5]);
        }
    }

    void addTask(int id, int type, double x, double y, double z, double priority)
    {
        TaskInfo task;
        task.id = id;
        task.type = type;
        task.position << x, y, z;
        task.priority = priority;
        task.assigned = false;
        tasks_.push_back(task);
    }

    void loadObstacleList()
    {
        obstacles_.clear();
        XmlRpc::XmlRpcValue obstacle_list;
        if(!nh_.getParam("obstacle_list", obstacle_list) || obstacle_list.getType() != XmlRpc::XmlRpcValue::TypeArray)
        {
            // Keep the generic node clean when no obstacle scene is requested.
            return;
        }

        for(int i = 0; i < obstacle_list.size(); ++i)
        {
            vector<double> row;
            if(!parseDoubleArray(obstacle_list[i], row) || row.size() < 12)
            {
                ROS_WARN("[%s] Skip invalid obstacle row %d. Expected [id,type,x,y,z,sx,sy,sz,r,g,b,a].", NODE_NAME, i);
                continue;
            }
            StaticObstacle obs;
            obs.id = static_cast<int>(row[0]);
            obs.type = static_cast<int>(row[1]);
            obs.position << row[2], row[3], row[4];
            obs.size << std::max(0.05, row[5]), std::max(0.05, row[6]), std::max(0.05, row[7]);
            obs.r = std::max(0.0, std::min(row[8], 1.0));
            obs.g = std::max(0.0, std::min(row[9], 1.0));
            obs.b = std::max(0.0, std::min(row[10], 1.0));
            obs.a = std::max(0.05, std::min(row[11], 1.0));
            obstacles_.push_back(obs);
        }
    }

    string obstacleTypeName(int type) const
    {
        if(type == 0) return "Box";
        if(type == 1) return "Cylinder";
        if(type == 2) return "DangerZone";
        return "Unknown";
    }

    void loadDemoUavPositions()
    {
        // Default positions are only used when no real DroneState is available or use_demo_positions=true.
        for(int i = 0; i < swarm_num_uav_; ++i)
        {
            uavs_[i].position << 0.0, (i - 2) * 3.0, default_height_;
            uavs_[i].velocity.setZero();
            uavs_[i].has_state = use_demo_positions_;
        }

        XmlRpc::XmlRpcValue positions;
        if(!nh_.getParam("demo_uav_positions", positions) || positions.getType() != XmlRpc::XmlRpcValue::TypeArray)
        {
            return;
        }

        for(int i = 0; i < positions.size(); ++i)
        {
            vector<double> row;
            if(!parseDoubleArray(positions[i], row) || row.size() < 4)
            {
                continue;
            }
            const int id = static_cast<int>(row[0]);
            if(id < 1 || id > swarm_num_uav_)
            {
                continue;
            }
            uavs_[id - 1].position << row[1], row[2], row[3];
            uavs_[id - 1].has_state = true;
        }
    }

    void initRosIO()
    {
        marker_pub_ = nh_.advertise<visualization_msgs::MarkerArray>("assignment_markers", 1, true);
        uav_model_marker_pub_ = nh_.advertise<visualization_msgs::MarkerArray>("uav_model_markers", 1, true);
        result_text_pub_ = nh_.advertise<std_msgs::String>("assignment_result_text", 1, true);

        if(use_gazebo_model_states_for_rviz_uav_)
        {
            gazebo_model_state_sub_ = nh_.subscribe<gazebo_msgs::ModelStates>(
                "/gazebo/model_states", 10, &SwarmTaskAssignmentMappoNode::gazeboModelStatesCb, this);
        }

        uav_model_marker_timer_ = nh_.createTimer(ros::Duration(std::max(0.02, uav_model_marker_period_)),
                                                  &SwarmTaskAssignmentMappoNode::uavModelMarkerTimerCb,
                                                  this);

        if(enable_gazebo_visualization_)
        {
            gazebo_spawn_client_ = nh_.serviceClient<gazebo_msgs::SpawnModel>("/gazebo/spawn_sdf_model");
            gazebo_delete_client_ = nh_.serviceClient<gazebo_msgs::DeleteModel>("/gazebo/delete_model");
        }

        for(int i = 1; i <= swarm_num_uav_; ++i)
        {
            const string uav_name = "/uav" + std::to_string(i);
            drone_state_sub_[i] = nh_.subscribe<prometheus_msgs::DroneState>(
                uav_name + "/prometheus/drone_state", 10,
                boost::bind(&SwarmTaskAssignmentMappoNode::droneStateCb, this, _1, i));

            command_pub_[i] = nh_.advertise<prometheus_msgs::SwarmCommand>(
                uav_name + "/prometheus/swarm_command", 10);

            path_pub_[i] = nh_.advertise<nav_msgs::Path>(
                "uav" + std::to_string(i) + "_assignment_path", 1, true);
        }
    }

    void droneStateCb(const prometheus_msgs::DroneState::ConstPtr& msg, int uav_id)
    {
        if(uav_id < 1 || uav_id > swarm_num_uav_)
        {
            return;
        }
        if(use_demo_positions_)
        {
            return;
        }
        UavInfo& uav = uavs_[uav_id - 1];
        uav.position << msg->position[0], msg->position[1], msg->position[2];
        uav.velocity << msg->velocity[0], msg->velocity[1], msg->velocity[2];
        uav.has_state = true;
        uav.available = true;
    }

    void gazeboModelStatesCb(const gazebo_msgs::ModelStates::ConstPtr& msg)
    {
        gazebo_model_pose_map_.clear();
        for(size_t i = 0; i < msg->name.size() && i < msg->pose.size(); ++i)
        {
            gazebo_model_pose_map_[msg->name[i]] = msg->pose[i];
        }
    }

    bool getGazeboUavPose(int uav_id, geometry_msgs::Pose& pose) const
    {
        const int idx = uav_id - 1;
        if(idx < 0 || idx >= static_cast<int>(uav_model_names_.size()))
        {
            return false;
        }
        auto it = gazebo_model_pose_map_.find(uav_model_names_[idx]);
        if(it == gazebo_model_pose_map_.end())
        {
            return false;
        }
        pose = it->second;
        return true;
    }

    bool getRvizUavPose(const UavInfo& uav, geometry_msgs::Pose& pose) const
    {
        pose.orientation.w = 1.0;
        pose.position = toPoint(uav.position);

        if(use_gazebo_model_states_for_rviz_uav_)
        {
            geometry_msgs::Pose gazebo_pose;
            if(getGazeboUavPose(uav.id, gazebo_pose))
            {
                pose = gazebo_pose;
                return true;
            }
        }
        return false;
    }

    bool syncUavPositionsFromGazebo()
    {
        if(!use_gazebo_model_states_for_assignment_)
        {
            return true;
        }

        bool all_ready = true;
        for(auto& uav : uavs_)
        {
            geometry_msgs::Pose gazebo_pose;
            if(!getGazeboUavPose(uav.id, gazebo_pose))
            {
                all_ready = false;
                continue;
            }
            uav.position << gazebo_pose.position.x, gazebo_pose.position.y, gazebo_pose.position.z;
            uav.has_state = true;
            uav.available = true;
        }
        return all_ready;
    }

    string getUavMeshResource(int uav_id) const
    {
        const int idx = uav_id - 1;
        if(idx >= 0 && idx < static_cast<int>(uav_mesh_resources_.size()) && !uav_mesh_resources_[idx].empty())
        {
            return uav_mesh_resources_[idx];
        }
        return default_uav_mesh_resource_;
    }

    void uavModelMarkerTimerCb(const ros::TimerEvent&)
    {
        if(!enable_rviz_visualization_)
        {
            return;
        }

        visualization_msgs::MarkerArray marker_array;
        visualization_msgs::Marker clear;
        clear.header.frame_id = frame_id_;
        clear.header.stamp = ros::Time::now();
        clear.action = visualization_msgs::Marker::DELETEALL;
        marker_array.markers.push_back(clear);

        int id = 1;
        for(const auto& uav : uavs_)
        {
            geometry_msgs::Pose pose;
            getRvizUavPose(uav, pose);
            pose.position.z += rviz_uav_mesh_z_offset_;

            const string mesh_resource = getUavMeshResource(uav.id);
            visualization_msgs::Marker model_marker;
            if(visualize_uav_as_mesh_ && !mesh_resource.empty())
            {
                model_marker = baseMarker("uav_real_model_mesh", id++, visualization_msgs::Marker::MESH_RESOURCE);
                model_marker.mesh_resource = mesh_resource;
                // STL files normally do not contain useful embedded materials.
                // Use explicit marker color so RViz can render the UAV body clearly.
                model_marker.mesh_use_embedded_materials = false;
                model_marker.scale.x = rviz_uav_mesh_scale_;
                model_marker.scale.y = rviz_uav_mesh_scale_;
                model_marker.scale.z = rviz_uav_mesh_scale_;
                setColor(model_marker, 0.85, 0.85, 0.85, 1.0);
            }
            else
            {
                // Fallback: still avoid using a sphere for UAVs. If no mesh path is configured,
                // show a simple arrow so the user knows the model resource is missing.
                model_marker = baseMarker("uav_real_model_fallback_arrow", id++, visualization_msgs::Marker::ARROW);
                model_marker.scale.x = 1.0;
                model_marker.scale.y = 0.25;
                model_marker.scale.z = 0.25;
                setColor(model_marker, 0.1, 0.9, 0.2, 0.9);
            }
            model_marker.pose = pose;
            model_marker.lifetime = ros::Duration(std::max(0.2, 3.0 * uav_model_marker_period_));
            marker_array.markers.push_back(model_marker);

            visualization_msgs::Marker text = baseMarker("uav_real_model_text", id++, visualization_msgs::Marker::TEXT_VIEW_FACING);
            text.pose.position.x = pose.position.x;
            text.pose.position.y = pose.position.y;
            text.pose.position.z = pose.position.z + 0.9;
            text.scale.z = 0.42;
            setColor(text, 1.0, 1.0, 1.0, 1.0);
            std::stringstream ss;
            ss << "UAV" << uav.id;
            text.text = ss.str();
            text.lifetime = ros::Duration(std::max(0.2, 3.0 * uav_model_marker_period_));
            marker_array.markers.push_back(text);
        }

        uav_model_marker_pub_.publish(marker_array);
    }


    bool allRequiredStatesReady()
    {
        if(use_demo_positions_)
        {
            return true;
        }

        if(use_gazebo_model_states_for_assignment_)
        {
            const bool gazebo_ready = syncUavPositionsFromGazebo();
            if(wait_for_gazebo_model_states_)
            {
                return gazebo_ready;
            }
            if(gazebo_ready)
            {
                return true;
            }
            // If Gazebo model_states are not ready and the user does not want to wait,
            // fall back to DroneState.
        }

        for(const auto& uav : uavs_)
        {
            if(!uav.has_state)
            {
                return false;
            }
        }
        return true;
    }

    void assignmentTimerCb(const ros::TimerEvent&)
    {
        if(run_once_ && has_run_once_)
        {
            return;
        }
        if(!allRequiredStatesReady())
        {
            if(use_gazebo_model_states_for_assignment_)
            {
                ROS_WARN_THROTTLE(2.0, "[%s] Waiting for all Gazebo models in /gazebo/model_states. Expected names: %s",
                                  NODE_NAME, stringVectorToString(uav_model_names_).c_str());
            }
            else
            {
                ROS_WARN_THROTTLE(2.0, "[%s] Waiting for /uavX/prometheus/drone_state of all UAVs...", NODE_NAME);
            }
            return;
        }

        ros::Time t0 = ros::Time::now();
        AssignmentMetrics metrics;
        vector<int> unassigned_tasks;
        vector<int> idle_uavs;
        vector<AssignmentResult> results = solver_.solve(uavs_, tasks_, metrics, unassigned_tasks, idle_uavs);
        metrics.compute_time_ms = (ros::Time::now() - t0).toSec() * 1000.0;

        if(enable_rviz_visualization_)
        {
            publishVisualization(results, unassigned_tasks, idle_uavs);
            publishAssignmentPaths(results);
        }
        if(enable_gazebo_visualization_)
        {
            publishGazeboVisualization(results);
        }
        publishResultText(results, metrics, unassigned_tasks, idle_uavs);
        printResult(results, metrics, unassigned_tasks, idle_uavs);

        if(auto_dispatch_commands_)
        {
            dispatchCommands(results);
        }
        has_run_once_ = true;
    }

    void dispatchCommands(const vector<AssignmentResult>& results)
    {
        for(const auto& r : results)
        {
            if(r.uav_id < 1 || r.uav_id > swarm_num_uav_)
            {
                continue;
            }
            prometheus_msgs::SwarmCommand cmd;
            cmd.header.stamp = ros::Time::now();
            cmd.Mode = prometheus_msgs::SwarmCommand::Move;
            cmd.Move_mode = prometheus_msgs::SwarmCommand::XYZ_POS;
            cmd.Command_ID = ++command_id_[r.uav_id];
            cmd.source = string("/swarm_task_assignment_mappo");
            cmd.position_ref[0] = r.task_position.x();
            cmd.position_ref[1] = r.task_position.y();
            cmd.position_ref[2] = r.task_position.z();
            cmd.velocity_ref[0] = 0.0;
            cmd.velocity_ref[1] = 0.0;
            cmd.velocity_ref[2] = 0.0;
            cmd.acceleration_ref[0] = 0.0;
            cmd.acceleration_ref[1] = 0.0;
            cmd.acceleration_ref[2] = 0.0;
            cmd.yaw_ref = yaw_ref_;
            command_pub_[r.uav_id].publish(cmd);
        }
    }

    geometry_msgs::Point toPoint(const Eigen::Vector3d& p) const
    {
        geometry_msgs::Point pt;
        pt.x = p.x();
        pt.y = p.y();
        pt.z = p.z();
        return pt;
    }

    geometry_msgs::PoseStamped toPoseStamped(const Eigen::Vector3d& p) const
    {
        geometry_msgs::PoseStamped pose;
        pose.header.stamp = ros::Time::now();
        pose.header.frame_id = frame_id_;
        pose.pose.position = toPoint(p);
        pose.pose.orientation.w = 1.0;
        return pose;
    }

    void setColor(visualization_msgs::Marker& marker, double r, double g, double b, double a) const
    {
        marker.color.r = r;
        marker.color.g = g;
        marker.color.b = b;
        marker.color.a = a;
    }

    void taskColor(int task_type, double& r, double& g, double& b) const
    {
        if(task_type == ATTACK)
        {
            r = 1.0; g = 0.15; b = 0.15;
        }
        else if(task_type == RECON)
        {
            r = 0.10; g = 0.45; b = 1.0;
        }
        else if(task_type == JAM)
        {
            r = 0.70; g = 0.20; b = 1.0;
        }
        else
        {
            r = 0.8; g = 0.8; b = 0.8;
        }
    }

    void setTaskColor(visualization_msgs::Marker& marker, int task_type, double alpha) const
    {
        double r, g, b;
        taskColor(task_type, r, g, b);
        setColor(marker, r, g, b, alpha);
    }

    visualization_msgs::Marker baseMarker(const string& ns, int id, int type) const
    {
        visualization_msgs::Marker marker;
        marker.header.frame_id = frame_id_;
        marker.header.stamp = ros::Time::now();
        marker.ns = ns;
        marker.id = id;
        marker.type = type;
        marker.action = visualization_msgs::Marker::ADD;
        marker.pose.orientation.w = 1.0;
        marker.lifetime = ros::Duration(assignment_period_ + 1.0);
        return marker;
    }

    vector<Eigen::Vector3d> buildDemoPath(const Eigen::Vector3d& start,
                                          const Eigen::Vector3d& goal,
                                          int uav_id) const
    {
        vector<Eigen::Vector3d> control_points;
        control_points.push_back(start);

        Eigen::Vector3d mid = 0.5 * (start + goal);
        mid.z() = std::max(start.z(), goal.z()) + path_mid_height_;

        Eigen::Vector3d dir = goal - start;
        Eigen::Vector3d side(-dir.y(), dir.x(), 0.0);
        if(side.norm() > 1e-3)
        {
            side.normalize();
            const double sign = (uav_id % 2 == 0) ? 1.0 : -1.0;
            mid += sign * path_side_offset_ * side;
        }
        control_points.push_back(mid);
        control_points.push_back(goal);

        vector<Eigen::Vector3d> samples;
        const int sample_num = std::max(path_sample_num_, 4);
        samples.reserve(sample_num + 1);
        for(int i = 0; i <= sample_num; ++i)
        {
            double t = static_cast<double>(i) / static_cast<double>(sample_num);
            // Quadratic Bezier curve: only used as assignment demonstration path, not real path planning.
            Eigen::Vector3d p = (1.0 - t) * (1.0 - t) * control_points[0]
                              + 2.0 * (1.0 - t) * t * control_points[1]
                              + t * t * control_points[2];
            samples.push_back(p);
        }
        return samples;
    }

    void publishAssignmentPaths(const vector<AssignmentResult>& results)
    {
        if(!publish_demo_paths_)
        {
            return;
        }

        for(const auto& r : results)
        {
            if(r.uav_id < 1 || r.uav_id > swarm_num_uav_)
            {
                continue;
            }
            nav_msgs::Path path;
            path.header.stamp = ros::Time::now();
            path.header.frame_id = frame_id_;
            vector<Eigen::Vector3d> samples = buildDemoPath(r.uav_position, r.task_position, r.uav_id);
            for(const auto& p : samples)
            {
                path.poses.push_back(toPoseStamped(p));
            }
            path_pub_[r.uav_id].publish(path);
        }
    }

    void publishObstacleMarkers(visualization_msgs::MarkerArray& marker_array, int& id) const
    {
        for(const auto& obs : obstacles_)
        {
            const bool is_box = (obs.type == 0);
            const bool is_danger_zone = (obs.type == 2);
            visualization_msgs::Marker marker = baseMarker("static_obstacle", id++,
                                                          is_box ? visualization_msgs::Marker::CUBE
                                                                 : visualization_msgs::Marker::CYLINDER);
            marker.pose.position = toPoint(obs.position);
            if(is_box)
            {
                marker.scale.x = obs.size.x();
                marker.scale.y = obs.size.y();
                marker.scale.z = obs.size.z();
            }
            else
            {
                marker.scale.x = 2.0 * obs.size.x();
                marker.scale.y = 2.0 * obs.size.x();
                marker.scale.z = obs.size.z();
            }
            setColor(marker, obs.r, obs.g, obs.b, obs.a);
            marker_array.markers.push_back(marker);

            visualization_msgs::Marker outline = baseMarker("static_obstacle_outline", id++, visualization_msgs::Marker::LINE_LIST);
            outline.scale.x = 0.05;
            setColor(outline, 1.0, 1.0, 1.0, is_danger_zone ? 0.55 : 0.35);
            if(is_box)
            {
                addBoxWireframePoints(outline, obs.position, obs.size);
                marker_array.markers.push_back(outline);
            }

            visualization_msgs::Marker text = baseMarker("static_obstacle_text", id++, visualization_msgs::Marker::TEXT_VIEW_FACING);
            text.pose.position.x = obs.position.x();
            text.pose.position.y = obs.position.y();
            text.pose.position.z = obs.position.z() + 0.5 * obs.size.z() + 0.8;
            text.scale.z = 0.42;
            setColor(text, 1.0, 1.0, 1.0, 1.0);
            std::stringstream ss;
            ss << "Obs" << obs.id << " " << obstacleTypeName(obs.type);
            if(is_danger_zone) ss << "\n仅可视化危险区";
            text.text = ss.str();
            marker_array.markers.push_back(text);
        }
    }

    void addBoxWireframePoints(visualization_msgs::Marker& marker,
                               const Eigen::Vector3d& c,
                               const Eigen::Vector3d& s) const
    {
        const double hx = 0.5 * s.x();
        const double hy = 0.5 * s.y();
        const double hz = 0.5 * s.z();
        std::vector<Eigen::Vector3d> v(8);
        v[0] = c + Eigen::Vector3d(-hx, -hy, -hz);
        v[1] = c + Eigen::Vector3d( hx, -hy, -hz);
        v[2] = c + Eigen::Vector3d( hx,  hy, -hz);
        v[3] = c + Eigen::Vector3d(-hx,  hy, -hz);
        v[4] = c + Eigen::Vector3d(-hx, -hy,  hz);
        v[5] = c + Eigen::Vector3d( hx, -hy,  hz);
        v[6] = c + Eigen::Vector3d( hx,  hy,  hz);
        v[7] = c + Eigen::Vector3d(-hx,  hy,  hz);
        const int e[12][2] = {{0,1},{1,2},{2,3},{3,0},{4,5},{5,6},{6,7},{7,4},{0,4},{1,5},{2,6},{3,7}};
        for(int i = 0; i < 12; ++i)
        {
            marker.points.push_back(toPoint(v[e[i][0]]));
            marker.points.push_back(toPoint(v[e[i][1]]));
        }
    }

    void publishVisualization(const vector<AssignmentResult>& results,
                              const vector<int>& unassigned_tasks,
                              const vector<int>& idle_uavs)
    {
        visualization_msgs::MarkerArray marker_array;
        visualization_msgs::Marker clear;
        clear.header.frame_id = frame_id_;
        clear.header.stamp = ros::Time::now();
        clear.action = visualization_msgs::Marker::DELETEALL;
        marker_array.markers.push_back(clear);

        int id = 1;
        for(const auto& uav : uavs_)
        {
            // UAV body is displayed by /swarm_task_assignment_mappo/uav_model_markers as a mesh.
            // Keep only capability text here; do not use a sphere to represent UAV start position.
            geometry_msgs::Pose uav_pose;
            getRvizUavPose(uav, uav_pose);

            visualization_msgs::Marker text = baseMarker("uav_capability_text", id++, visualization_msgs::Marker::TEXT_VIEW_FACING);
            text.pose.position.x = uav_pose.position.x;
            text.pose.position.y = uav_pose.position.y;
            text.pose.position.z = uav_pose.position.z + 1.35;
            text.scale.z = 0.36;
            setColor(text, 1.0, 1.0, 1.0, 1.0);
            std::stringstream ss;
            ss << "cap[";
            for(size_t k = 0; k < uav.capability.size(); ++k)
            {
                ss << uav.capability[k];
                if(k + 1 < uav.capability.size()) ss << ",";
            }
            ss << "]";
            text.text = ss.str();
            marker_array.markers.push_back(text);
        }

        if(enable_obstacle_visualization_)
        {
            publishObstacleMarkers(marker_array, id);
        }

        for(const auto& task : tasks_)
        {
            visualization_msgs::Marker task_marker = baseMarker("task_target_position", id++, visualization_msgs::Marker::CUBE);
            task_marker.pose.position = toPoint(task.position);
            task_marker.scale.x = 0.75;
            task_marker.scale.y = 0.75;
            task_marker.scale.z = 0.75;
            setTaskColor(task_marker, task.type, 0.9);
            marker_array.markers.push_back(task_marker);

            visualization_msgs::Marker vertical_line = baseMarker("task_height_line", id++, visualization_msgs::Marker::LINE_STRIP);
            vertical_line.scale.x = 0.04;
            setTaskColor(vertical_line, task.type, 0.7);
            Eigen::Vector3d ground(task.position.x(), task.position.y(), 0.02);
            vertical_line.points.push_back(toPoint(ground));
            vertical_line.points.push_back(toPoint(task.position));
            marker_array.markers.push_back(vertical_line);

            visualization_msgs::Marker text = baseMarker("task_text", id++, visualization_msgs::Marker::TEXT_VIEW_FACING);
            text.pose.position = toPoint(task.position + Eigen::Vector3d(0.0, 0.0, 1.1));
            text.scale.z = 0.45;
            setColor(text, 1.0, 1.0, 1.0, 1.0);
            std::stringstream ss;
            ss << "T" << task.id << " " << taskTypeToChinese(task.type) << "\nP=" << task.priority;
            text.text = ss.str();
            marker_array.markers.push_back(text);
        }

        for(const auto& r : results)
        {
            vector<Eigen::Vector3d> samples = buildDemoPath(r.uav_position, r.task_position, r.uav_id);

            visualization_msgs::Marker line = baseMarker("assignment_demo_path", id++, visualization_msgs::Marker::LINE_STRIP);
            line.scale.x = 0.10;
            setTaskColor(line, r.task_type, 0.95);
            for(const auto& p : samples)
            {
                line.points.push_back(toPoint(p));
            }
            marker_array.markers.push_back(line);

            visualization_msgs::Marker points = baseMarker("assignment_demo_waypoints", id++, visualization_msgs::Marker::SPHERE_LIST);
            points.scale.x = 0.18;
            points.scale.y = 0.18;
            points.scale.z = 0.18;
            setTaskColor(points, r.task_type, 0.95);
            for(size_t k = 0; k < samples.size(); k += 2)
            {
                points.points.push_back(toPoint(samples[k]));
            }
            marker_array.markers.push_back(points);

            Eigen::Vector3d mid = samples[samples.size() / 2];
            visualization_msgs::Marker text = baseMarker("assignment_text", id++, visualization_msgs::Marker::TEXT_VIEW_FACING);
            text.pose.position = toPoint(mid + Eigen::Vector3d(0.0, 0.0, 0.6));
            text.scale.z = 0.4;
            setColor(text, 1.0, 1.0, 0.4, 1.0);
            std::stringstream ss;
            ss << "UAV" << r.uav_id << " -> T" << r.task_id << "\nscore=" << fixed << setprecision(2) << r.score;
            text.text = ss.str();
            marker_array.markers.push_back(text);
        }

        visualization_msgs::Marker legend = baseMarker("legend", id++, visualization_msgs::Marker::TEXT_VIEW_FACING);
        legend.pose.position.x = 1.0;
        legend.pose.position.y = -10.0;
        legend.pose.position.z = 4.0;
        legend.scale.z = 0.45;
        setColor(legend, 1.0, 1.0, 1.0, 1.0);
        std::stringstream ss;
        ss << "MAPPO任务分配可视化\nRViz无人机: 使用Mesh模型显示  红:攻击  蓝:侦察  紫:干扰\n";
        ss << "彩色曲线/小点: 分配后的示意Path, 非真实路径规划\n";
        ss << "灰色/橙色/半透明红色: 静态障碍物/危险区, 当前阶段不做避障规划\n";
        ss << "未分配任务: " << vectorToString(unassigned_tasks) << "\n";
        ss << "空闲无人机: " << vectorToString(idle_uavs);
        legend.text = ss.str();
        marker_array.markers.push_back(legend);

        marker_pub_.publish(marker_array);
    }

    string sdfSphereXml(const string& model_name,
                        double radius,
                        double r,
                        double g,
                        double b,
                        double a,
                        bool enable_collision) const
    {
        std::stringstream ss;
        ss << "<sdf version='1.6'>"
           << "<model name='" << model_name << "'>"
           << "<static>true</static>"
           << "<link name='link'>"
           << "<gravity>false</gravity>"
           << "<visual name='visual'>"
           << "<geometry><sphere><radius>" << radius << "</radius></sphere></geometry>"
           << "<material><ambient>" << r << " " << g << " " << b << " " << a << "</ambient>"
           << "<diffuse>" << r << " " << g << " " << b << " " << a << "</diffuse></material>"
           << "</visual>";
        if(enable_collision)
        {
            ss << "<collision name='collision'>"
               << "<geometry><sphere><radius>" << radius << "</radius></sphere></geometry>"
               << "</collision>";
        }
        ss << "</link>"
           << "</model>"
           << "</sdf>";
        return ss.str();
    }

    string sdfObstacleXml(const string& model_name,
                          const StaticObstacle& obs,
                          bool enable_collision) const
    {
        const bool is_box = (obs.type == 0);
        const bool is_danger_zone = (obs.type == 2);
        const double transparency = std::max(0.0, std::min(1.0 - obs.a, 0.95));
        std::stringstream ss;
        ss << "<sdf version='1.6'>"
           << "<model name='" << model_name << "'>"
           << "<static>true</static>"
           << "<link name='link'>"
           << "<gravity>false</gravity>"
           << "<visual name='visual'>";
        if(is_box)
        {
            ss << "<geometry><box><size>" << obs.size.x() << " " << obs.size.y() << " " << obs.size.z()
               << "</size></box></geometry>";
        }
        else
        {
            ss << "<geometry><cylinder><radius>" << obs.size.x() << "</radius><length>" << obs.size.z()
               << "</length></cylinder></geometry>";
        }
        ss << "<material><ambient>" << obs.r << " " << obs.g << " " << obs.b << " " << obs.a << "</ambient>"
           << "<diffuse>" << obs.r << " " << obs.g << " " << obs.b << " " << obs.a << "</diffuse></material>"
           << "<transparency>" << transparency << "</transparency>"
           << "</visual>";
        if(enable_collision && !is_danger_zone)
        {
            ss << "<collision name='collision'>";
            if(is_box)
            {
                ss << "<geometry><box><size>" << obs.size.x() << " " << obs.size.y() << " " << obs.size.z()
                   << "</size></box></geometry>";
            }
            else
            {
                ss << "<geometry><cylinder><radius>" << obs.size.x() << "</radius><length>" << obs.size.z()
                   << "</length></cylinder></geometry>";
            }
            ss << "</collision>";
        }
        ss << "</link>"
           << "</model>"
           << "</sdf>";
        return ss.str();
    }

    bool spawnGazeboObstacle(const StaticObstacle& obs)
    {
        const string name = "mappo_static_obstacle_" + std::to_string(obs.id);
        gazebo_msgs::DeleteModel del_srv;
        del_srv.request.model_name = name;
        gazebo_delete_client_.call(del_srv);

        gazebo_msgs::SpawnModel srv;
        srv.request.model_name = name;
        srv.request.model_xml = sdfObstacleXml(name, obs, gazebo_obstacle_collision_);
        srv.request.robot_namespace = "";
        srv.request.reference_frame = "world";
        srv.request.initial_pose.position.x = obs.position.x();
        srv.request.initial_pose.position.y = obs.position.y();
        srv.request.initial_pose.position.z = obs.position.z();
        srv.request.initial_pose.orientation.w = 1.0;

        if(!gazebo_spawn_client_.call(srv))
        {
            ROS_WARN("[%s] Failed to call /gazebo/spawn_sdf_model for %s.", NODE_NAME, name.c_str());
            return false;
        }
        if(!srv.response.success)
        {
            ROS_WARN_THROTTLE(2.0, "[%s] Gazebo obstacle spawn failed for %s: %s", NODE_NAME, name.c_str(), srv.response.status_message.c_str());
            return false;
        }
        gazebo_model_names_.push_back(name);
        return true;
    }

    bool spawnGazeboSphere(const string& name,
                           const Eigen::Vector3d& position,
                           double radius,
                           double r,
                           double g,
                           double b,
                           double a,
                           bool enable_collision = false)
    {
        // Delete the old marker with the same name first. This avoids Gazebo spawn failure
        // when roslaunch is restarted but the Gazebo process is still alive.
        gazebo_msgs::DeleteModel del_srv;
        del_srv.request.model_name = name;
        gazebo_delete_client_.call(del_srv);

        gazebo_msgs::SpawnModel srv;
        srv.request.model_name = name;
        srv.request.model_xml = sdfSphereXml(name, radius, r, g, b, a, enable_collision);
        srv.request.robot_namespace = "";
        srv.request.reference_frame = "world";
        srv.request.initial_pose.position.x = position.x();
        srv.request.initial_pose.position.y = position.y();
        srv.request.initial_pose.position.z = position.z();
        srv.request.initial_pose.orientation.w = 1.0;

        if(!gazebo_spawn_client_.call(srv))
        {
            ROS_WARN("[%s] Failed to call /gazebo/spawn_sdf_model for %s.", NODE_NAME, name.c_str());
            return false;
        }
        if(!srv.response.success)
        {
            ROS_WARN_THROTTLE(2.0, "[%s] Gazebo spawn failed for %s: %s", NODE_NAME, name.c_str(), srv.response.status_message.c_str());
            return false;
        }
        gazebo_model_names_.push_back(name);
        return true;
    }

    void clearGazeboModels()
    {
        for(const auto& name : gazebo_model_names_)
        {
            gazebo_msgs::DeleteModel srv;
            srv.request.model_name = name;
            gazebo_delete_client_.call(srv);
        }
        gazebo_model_names_.clear();
        gazebo_models_spawned_ = false;
    }

    void publishGazeboVisualization(const vector<AssignmentResult>& results)
    {
        // Gazebo does not display RViz MarkerArray. Here we spawn simple static SDF spheres so
        // task targets and demonstration paths can be seen directly in Gazebo.
        if(gazebo_models_spawned_ && !gazebo_respawn_each_assignment_)
        {
            return;
        }

        if(!gazebo_spawn_client_.exists())
        {
            ROS_WARN_THROTTLE(2.0, "[%s] /gazebo/spawn_sdf_model not ready. Gazebo task/path markers will wait.", NODE_NAME);
            return;
        }

        clearGazeboModels();

        if(enable_obstacle_visualization_)
        {
            for(const auto& obs : obstacles_)
            {
                spawnGazeboObstacle(obs);
            }
        }

        if(gazebo_show_uav_start_spheres_)
        {
            for(const auto& uav : uavs_)
            {
                spawnGazeboSphere("mappo_uav_start_" + std::to_string(uav.id),
                                  uav.position,
                                  gazebo_uav_marker_radius_,
                                  0.1, 0.9, 0.2, 0.85, gazebo_visual_collision_);
            }
        }

        for(const auto& task : tasks_)
        {
            double r, g, b;
            taskColor(task.type, r, g, b);
            spawnGazeboSphere("mappo_task_T" + std::to_string(task.id),
                              task.position,
                              gazebo_task_radius_,
                              r, g, b, 0.95, gazebo_visual_collision_);
        }

        for(const auto& rlt : results)
        {
            double r, g, b;
            taskColor(rlt.task_type, r, g, b);
            vector<Eigen::Vector3d> samples = buildDemoPath(rlt.uav_position, rlt.task_position, rlt.uav_id);

            // Do not spawn a path sphere exactly at the UAV pose or exactly at the task pose.
            // The start point can overlap with the real UAV model, and the goal point already has
            // a task sphere. Path spheres are visual-only and have collision disabled by default.
            const size_t begin_idx = static_cast<size_t>(std::max(0, gazebo_path_skip_start_points_));
            size_t end_idx = samples.size();
            if(gazebo_path_skip_goal_points_ > 0 && static_cast<size_t>(gazebo_path_skip_goal_points_) < end_idx)
            {
                end_idx -= static_cast<size_t>(gazebo_path_skip_goal_points_);
            }

            for(size_t i = begin_idx; i < end_idx; i += 2)
            {
                const string name = "mappo_path_U" + std::to_string(rlt.uav_id) + "_T" +
                                    std::to_string(rlt.task_id) + "_" + std::to_string(i);
                Eigen::Vector3d p = samples[i];
                p.z() += gazebo_path_marker_z_offset_;
                spawnGazeboSphere(name, p, gazebo_path_marker_radius_, r, g, b, 0.85, gazebo_visual_collision_);
            }
        }

        gazebo_models_spawned_ = true;
    }

    void publishResultText(const vector<AssignmentResult>& results,
                           const AssignmentMetrics& metrics,
                           const vector<int>& unassigned_tasks,
                           const vector<int>& idle_uavs)
    {
        std_msgs::String msg;
        msg.data = buildResultString(results, metrics, unassigned_tasks, idle_uavs);
        result_text_pub_.publish(msg);
    }

    string buildResultString(const vector<AssignmentResult>& results,
                             const AssignmentMetrics& metrics,
                             const vector<int>& unassigned_tasks,
                             const vector<int>& idle_uavs) const
    {
        stringstream ss;
        ss << fixed << setprecision(2);
        ss << "MAPPO Assignment Result\n";
        for(const auto& r : results)
        {
            ss << "UAV" << r.uav_id << " -> T" << r.task_id << "(" << taskTypeToChinese(r.task_type)
               << "), score=" << r.score << ", distance=" << r.distance << " m\n";
        }
        ss << "assigned=" << metrics.assigned_num << "/" << metrics.total_task
           << ", success_rate=" << metrics.success_rate * 100.0 << "%"
           << ", total_distance=" << metrics.total_distance << " m"
           << ", avg_distance=" << metrics.avg_distance << " m"
           << ", compute_time=" << metrics.compute_time_ms << " ms\n";
        ss << "unassigned_tasks=" << vectorToString(unassigned_tasks)
           << ", idle_uavs=" << vectorToString(idle_uavs) << "\n";
        ss << "stage2_obstacles=" << obstacles_.size() << ", demo_path_is_not_planned_path=true\n";
        ss << "rviz_marker_topic=" << ros::this_node::getNamespace() << "/assignment_markers\n";
        ss << "rviz_path_topics=";
        for(int i = 1; i <= swarm_num_uav_; ++i)
        {
            ss << ros::this_node::getNamespace() << "/uav" << i << "_assignment_path";
            if(i < swarm_num_uav_) ss << ", ";
        }
        return ss.str();
    }

    void printResult(const vector<AssignmentResult>& results,
                     const AssignmentMetrics& metrics,
                     const vector<int>& unassigned_tasks,
                     const vector<int>& idle_uavs) const
    {
        cout << "\n=========== MAPPO Sequential Task Assignment ===========\n";
        cout << fixed << setprecision(2);
        for(const auto& r : results)
        {
            cout << "UAV" << r.uav_id << " -> T" << r.task_id
                 << " [" << taskTypeToChinese(r.task_type) << "]"
                 << "  score=" << r.score
                 << "  dist=" << r.distance << " m" << endl;
        }
        cout << "assigned: " << metrics.assigned_num << "/" << metrics.total_task
             << "  success_rate: " << metrics.success_rate * 100.0 << "%"
             << "  total_distance: " << metrics.total_distance << " m"
             << "  avg_distance: " << metrics.avg_distance << " m"
             << "  compute_time: " << metrics.compute_time_ms << " ms" << endl;
        cout << "unassigned_tasks: " << vectorToString(unassigned_tasks) << endl;
        cout << "idle_uavs: " << vectorToString(idle_uavs) << endl;
        cout << "RViz MarkerArray topic: " << ros::this_node::getNamespace() << "/assignment_markers" << endl;
        cout << "RViz Path topics: " << ros::this_node::getNamespace() << "/uavX_assignment_path" << endl;
        cout << "Stage2 obstacles: " << obstacles_.size() << "  demo_path_is_not_planned_path: true" << endl;
        cout << "Gazebo markers: " << (enable_gazebo_visualization_ ? "enabled" : "disabled") << endl;
        cout << "========================================================\n";
    }
};

int main(int argc, char** argv)
{
    ros::init(argc, argv, NODE_NAME);
    SwarmTaskAssignmentMappoNode node;
    ros::spin();
    return 0;
}
